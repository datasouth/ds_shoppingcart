<?php 
defined('C5_EXECUTE') or die('Access Denied.');
?>
<a href="<?php echo $view->url('/shopping_cart/add/'.$pageId); ?>" class="btn btn-default">Buy</a>